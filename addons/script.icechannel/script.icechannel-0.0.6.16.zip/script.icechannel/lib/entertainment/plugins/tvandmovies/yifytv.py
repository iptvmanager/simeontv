'''
    Ice Channel
    yify.tv
    Copyright (C) 2013 the-one
'''

from entertainment.plugnplay.interfaces import MovieSource
from entertainment.plugnplay import Plugin
from entertainment import common

class yifytv(MovieSource):
    implements = [MovieSource]
    
    name = "Yify.tv"
    display_name = "Yify TV"

    base_url='http://yify.tv'
    
    source_enabled_by_default = 'false'
    
    def GetFileHosts(self, url, list, lock, message_queue):
        import re
        from entertainment.net import Net
        
        net = Net()
        html = net.http_GET(url).content
        
        net._cached = False
        
        video_request_param = re.search('showPkPlayer\("(.+?)"\)', html)
        if video_request_param:
            video_request_param = video_request_param.group(1)
        else:
            return
            
        video_reqest_dict = 'url=https%3A//picasaweb.google.com/' + video_request_param + '&_' + common.GetEpochStr()
        
        import urllib
        video_request_url = self.base_url + '/reproductor2/pk/pk/plugins/player_picasa.php?' + video_reqest_dict

        videos = net.http_GET(video_request_url).content
        
        quality_dict = {'1920':'HD', '1280':'HD', '854':'SD', '640':'LOW', '426':'LOW'}
        
        import json
        video_links = json.loads(videos)
        for video_link in video_links:
            if 'videoplayback' in video_link['url']:
                self.AddFileHost(list, quality_dict.get(str(video_link['width']), 'NA'), video_link['url'], host='YIFY.TV')
        
    def GetFileHostsForContent(self, title, name, year, season, episode, type, list, lock, message_queue):                 
        import re
        from entertainment.net import Net
        
        net = Net()
        
        title = self.CleanTextForSearch(title) 
        name = self.CleanTextForSearch(name) 
        name_lower = name.lower()
            
        import urllib
        from entertainment import odict
        search_dict = odict.odict({'years':year, 's':name})
        search_dict.sort(key=lambda x: x[0].lower())
        
        search_for_url = self.base_url + '/?' + urllib.urlencode(search_dict)
        
        search_content = net.http_GET(search_for_url).content
        for search_item in re.finditer('(?s)<div class="tooltip"><a href="(.+?)">.+?</a>.+?<div class="tool_titulo">(.+?)</div>', search_content):
            item_link = search_item.group(1)
            item_name_year = search_item.group(2).lower()
            if name_lower in item_name_year and year in item_name_year:
                self.GetFileHosts(item_link, list, lock, message_queue)
                break
                
    def Resolve(self, url):
        return url          
